import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { SchedulesComponent } from './schedules/schedules.component';
import { FlightsComponent } from './flights/flights.component';
import { BookinglistComponent } from './bookinglist/bookinglist.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminGuard } from './_helpers/admin.guard';
import { AuthGuard } from './_helpers/auth.guard';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { DiscountComponent } from './discount/discount.component';
import { BookingComponent } from './booking/booking.component';

const routes: Routes = [
  {path : 'login',component:LoginComponent},
  {path: 'register',component:RegisterComponent},
  // {path : 'booking',component:TicketBookingComponent},
  {path : 'payment',component:PaymentComponent,canActivate: [AuthGuard]},
  {path:'admin',component:AdminComponent ,canActivate: [AdminGuard]},
  {path:'admin/manageAirLines',component:FlightsComponent,canActivate: [AdminGuard]},
  {path:'admin/manageSchedules',component:SchedulesComponent,canActivate: [AdminGuard]},
  {path:'admin/manageDiscounts',component:DiscountComponent,canActivate: [AdminGuard]},
  {path:'user',component:UserComponent,canActivate: [AuthGuard]},
  {path : 'payment',component:PaymentComponent,canActivate: [AuthGuard]},
  {path:'user/history',component:BookingComponent, canActivate: [AuthGuard]},
  {path:'user/list',component:BookinglistComponent,canActivate: [AuthGuard]},
  // {path:'user/checkin',component:CheckinComponent,canActivate: [AuthGuard]},
  {path : '',redirectTo:"/user",pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
