import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { promoData } from '../data';
import { Discount } from '../model/discount';
import { Flight } from '../model/flight';
import { DiscountService } from '../_services/discount.service';
import { FlightService } from '../_services/flight.service';

@Component({
  selector: 'app-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.scss']
})
export class DiscountComponent implements OnInit {

  managePromos = promoData;
  public flightListData:any=[];
  addPromoFrom = new FormGroup({});
  editPromoFrom = new FormGroup({});
  closeResult = '';
  public flightPromoList:any=[];
  private updatedId:number=0;
  private deletedId:number=0;


  constructor(private modalService: NgbModal,
    private fb: FormBuilder,
    private flightService : FlightService,
    private flightpromoService: DiscountService) { }

  ngOnInit(): void {
    this.getAllFightsList();
    this.addPromoFrom = this.fb.group({
      flightId: ['', Validators.required],
      code: ['', Validators.required],
      discount: ['', Validators.required],
      expiryDate: ['', Validators.required]

    });


    this.editPromoFrom = this.fb.group({
      flightId: ['', Validators.required],
      code: ['', Validators.required],
      discount: ['', Validators.required],
      expiryDate: ['', Validators.required]

    });

    this.getAllPromos();

  }

  getAllFightsList() {
    this.flightService.getAllFlightsData()
    .subscribe(
      (response:Flight) => {                           //next() callback
        this.flightListData = response; 
        
        
      },
      (error) => {                              //error() callback
        console.error('Request failed with error')
       
      })
  }


  getAllPromos() {
    this.flightpromoService.getAllFlightsData().subscribe(
      (response:Discount) => {                          
       
        this.flightPromoList = response; 
       
      },
      (error) => {                             
        alert('Request failed with error');
       
      });
      
  }


  open(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  openEdit(content: any,data:any) {
    console.log(data);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.updatedId = data.id;
    
    this.editPromoFrom.patchValue({
      flightId: data.flightId,
      code: data.code,
      discount: data.discount,
      expiryDate: data.expiryDate,
     });
  }

  addPromo(value:any){


    this.flightpromoService.addPromo(value ) .subscribe(data=>
       {
        this.modalService.dismissAll();
        this.getAllPromos();
    }, error=>console.log(error));



  }

  openDelete(content: any,data:any) {
    console.log(data);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.deletedId = data.id;
    
  }

  detelePromoCode(){
    this.flightpromoService.deletePromo(this.deletedId)
    .subscribe(data=> {console.log(data);
      this.modalService.dismissAll();
    },
    error=>console.log(error));
  
  this.getAllPromos();
}


updatePromo(value:any){


  this.flightpromoService.updatepromo(value ) .subscribe(data=>
     {console.log(data);
      this.getAllPromos();
      this.modalService.dismissAll();
  }, error=>console.log(error));



}

}
