import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { manageFlightData } from '../data';
import { Flight } from '../model/flight';
import { FlightService } from '../_services/flight.service';

@Component({
  selector: 'app-flights',
  templateUrl: './flights.component.html',
  styleUrls: ['./flights.component.scss']
})
export class FlightsComponent implements OnInit {

  modalReference:any= NgbModalRef;
  flight: Flight = new Flight("","","");
  isAdded = false;
  public flightListData:any=[];
  loading: boolean = false;
  errorMessage:string="";
  updatedId:number=0;
  deletedId:number=0;



  closeResult = '';
  flightManageData = manageFlightData;
  constructor(private modalService: NgbModal,
    private fb: FormBuilder,
    private flightService : FlightService) { }

  addFlightFrom = new FormGroup({});
  editFlightFrom = new FormGroup({});

  ngOnInit(): void {

    this.addFlightFrom = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      contact: ['', Validators.required]


    });

    this.editFlightFrom = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      contact: ['', Validators.required]


    });

    this.getAllFightsList();

  }

  open(content: any) {
  this.modalReference = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  openEdit(content: any,data:any) {
    console.log(data);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.updatedId = data.id;
    
    this.editFlightFrom.patchValue({
      name: data.name,
      email: data.email,
      contact: data.contact,
      id: data.id
     });
  }


  openDelete(content: any,data:any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.deletedId = data.id;
    
  }


  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }


  getAllFightsList() {
    this.flightService.getAllFlightsData()
    .subscribe(
      (response:Flight) => {                           //next() callback
        console.log('response received')
        this.flightListData = response; 
      },
      (error) => {                              //error() callback
        console.error('Request failed with error')
        this.errorMessage = error;
        this.loading = false;
      },
      () => {                                   //complete() callback
        console.error('Request completed')      //This is actually not needed 
        this.loading = false; 
      })


  }

  

  bookTickets(value:any){

    this.flightService.addFlights( value ) .subscribe(data=> {console.log(data);
      this.isAdded = true;
      alert("saved ");
      this.getAllFightsList();

    }, error=>console.log(error))

  }

  saveData(value:any){
    console.log(value);
    value.id=this.updatedId;
    this.flightService.updateFlights( value ) .subscribe(data=> {console.log(data);
      this.isAdded = true;
      alert("updated ");
    }, error=>console.log(error))

    this.getAllFightsList();
  }
  

  deteleFlight(){
    console.log(this.deletedId);
    this.flightService.deleteFlight(this.deletedId)
    .subscribe(data=> {console.log(data);
      alert("deleted ");
    },
    error=>console.log(error))
  
  this.getAllFightsList();
}

}
