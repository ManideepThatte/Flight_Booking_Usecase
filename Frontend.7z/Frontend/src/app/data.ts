export const data =
    [{ "id": 1, "sourceCity": "Lonee", "destinationCity": "Chasemoore", "date": "11/20/2020" },
    { "id": 2, "sourceCity": "Wendie", "destinationCity": "Vodden", "date": "04/21/2021" },
    { "id": 3, "sourceCity": "Calv", "destinationCity": "Bosnell", "date": "07/31/2021" },
    { "id": 4, "sourceCity": "Cathrin", "destinationCity": "Muscroft", "date": "05/25/2021" },
    { "id": 5, "sourceCity": "Gil", "destinationCity": "Ormesher", "date": "01/04/2021" },
    { "id": 6, "sourceCity": "Katalin", "destinationCity": "Clemendot", "date": "05/23/2021" },
    { "id": 7, "sourceCity": "Pierson", "destinationCity": "Sings", "date": "03/31/2021" },
    { "id": 8, "sourceCity": "Gladi", "destinationCity": "Sheringham", "date": "05/06/2021" },
    { "id": 9, "sourceCity": "Margie", "destinationCity": "MacDearmaid", "date": "09/06/2020" },
    { "id": 10, "sourceCity": "Kellyann", "destinationCity": "Dewicke", "date": "03/23/2021" }];


export const flightData = [{
    "image": "http://dummyimage.com/168x100.png/ff4444/ffffff",
    "ArrivalTime": "15:31",
    "depaertureTime": "8:44",
    "cost": 46
}, {
    "image": "http://dummyimage.com/115x100.png/ff4444/ffffff",
    "ArrivalTime": "14:54",
    "depaertureTime": "17:31",
    "cost": 51
}, {
    "image": "http://dummyimage.com/155x100.png/5fa2dd/ffffff",
    "ArrivalTime": "4:46",
    "depaertureTime": "13:31",
    "cost": 82
}, {
    "image": "http://dummyimage.com/135x100.png/dddddd/000000",
    "ArrivalTime": "0:24",
    "depaertureTime": "3:31",
    "cost": 30
}, {
    "image": "http://dummyimage.com/145x100.png/cc0000/ffffff",
    "ArrivalTime": "8:36",
    "depaertureTime": "1:48",
    "cost": 27
}, {
    "image": "http://dummyimage.com/178x100.png/cc0000/ffffff",
    "ArrivalTime": "6:56",
    "depaertureTime": "3:25",
    "cost": 14
}];


export const manageFlightData =
    [{
        "id": 1,
        "flight_logo": "http://dummyimage.com/x.png/ff4444/ffffff",
        "Flight_Name": "Air Asia",
        "email": "hrayson0@google.de",
        "contact": "839-617-9941"
    }, {
        "id": 2,
        "flight_logo": "http://dummyimage.com/x.png/5fa2dd/ffffff",
        "Flight_Name": "AirAsia India",
        "email": "fgoady1@baidu.com",
        "contact": "770-915-5654"
    }, {
        "id": 3,
        "flight_logo": "http://dummyimage.com/x.png/5fa2dd/ffffff",
        "Flight_Name": "Emirates",
        "email": "bdukesbury2@sun.com",
        "contact": "687-435-7671"
    }, {
        "id": 4,
        "flight_logo": "http://dummyimage.com/x.png/cc0000/ffffff",
        "Flight_Name": "IndiGo",
        "email": "tbaskett3@aboutads.info",
        "contact": "183-340-3787"
    }, {
        "id": 5,
        "flight_logo": "http://dummyimage.com/x.png/dddddd/000000",
        "Flight_Name": "Vistara",
        "email": "pdimitriou4@squidoo.com",
        "contact": "655-694-2875"
    }];

export const flightTimeData = [{ "id": 1, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "Ellis", "From": "Vistara", "To": "Burrel", "Date": "29/07/2021", "Time": "13:57" },
{
    "id": 2,
    "flight_logo": "http://dummyimage.com/50x50.png/cc0000/ffffff",
    "Flight_Name": "Air Asia",
    "From": "Guanba",
    "To": "Binhe",
    "Date": "23/10/2020",
    "Time": "9:45"
},
{ "id": 3, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "Emirates", "From": "Verkhniy Yasenov", "To": "Sibbo", "Date": "05/12/2020", "Time": "12:39" },
{ "id": 4, "flight_logo": "http://dummyimage.com/50x50.png/cc0000/ffffff", "Flight_Name": "IndiGo", "From": "Guitang", "To": "Monjarás", "Date": "15/05/2021", "Time": "19:48" },
{ "id": 5, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "King Fisher", "From": "Lepaterique", "To": "Inuvik", "Date": "22/11/2020", "Time": "19:20" }
];

export const promoData = [{ "id": 1, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "Ellis", "From": "Vistara", "To": "Burrel", "Date": "29/07/2021", "Time": "13:57" },
{
    "id": 2,
    "flight_logo": "http://dummyimage.com/50x50.png/cc0000/ffffff",
    "Flight_Name": "Air Asia",
    "From": "Guanba",
    "To": "Binhe",
    "Date": "23/10/2020",
    "Time": "9:45"
},
{ "id": 3, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "Emirates", "From": "Verkhniy Yasenov", "To": "Sibbo", "Date": "05/12/2020", "Time": "12:39" },
{ "id": 4, "flight_logo": "http://dummyimage.com/50x50.png/cc0000/ffffff", "Flight_Name": "IndiGo", "From": "Guitang", "To": "Monjarás", "Date": "15/05/2021", "Time": "19:48" },
{ "id": 5, "flight_logo": "http://dummyimage.com/50x50.png/dddddd/000000", "Flight_Name": "King Fisher", "From": "Lepaterique", "To": "Inuvik", "Date": "22/11/2020", "Time": "19:20" }
]



