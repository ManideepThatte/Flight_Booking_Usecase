import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../_services/flight.service';
import { ScheduleService } from '../_services/schedule.service';

@Component({
  selector: 'app-flightlist',
  templateUrl: './flightlist.component.html',
  styleUrls: ['./flightlist.component.scss']
})
export class FlightlistComponent implements OnInit {

  constructor(
    private flightService : FlightService,
    private schduleService:ScheduleService,
    private rout:Router,
   
  ) { 

  }

  //tbFlightData = flightData;
  bookdetails:any;
 


  @Input() flightScheduleDataDto:any ;


  ngOnInit(): void {
  }

  navigateToPayment(data:any){
    data.numberOfPassengers = this.flightScheduleDataDto.numberOfPassengers;
    console.log(data);
    localStorage.setItem('paymnetDetails', JSON.stringify(data));
    this.rout.navigateByUrl('/payment', { state:data});

  }

}
