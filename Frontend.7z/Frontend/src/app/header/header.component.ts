import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TokenStorageService } from '../_services/token-storage.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent  {

  isLoggedIn:boolean=false;


  // private roles: string[] = [];
  // isLoggedIn = false;
  // showAdminBoard = false;
  // username?: string;

  @Output() toggleSidebarForMe: EventEmitter<any> = new EventEmitter();

  constructor(public userService: UserService,private router: Router) {}

  // ngOnInit(): void {
  //   this.isLoggedIn = !!this.tokenStorageService.getToken();

  //   if (this.isLoggedIn) {
  //     const user = this.tokenStorageService.getUser();
  //     this.roles = user.roles;

  //     this.showAdminBoard = this.roles.includes('ROLE_ADMIN');

  //     this.username = user.username;
  //   }
  // }

  // logout(): void {
  //   this.tokenStorageService.signOut();
  //   //window.location.reload();
  //   this.router.navigate(['login']);
  // }

  toggleSidebar() {
    this.toggleSidebarForMe.emit();
  }



}