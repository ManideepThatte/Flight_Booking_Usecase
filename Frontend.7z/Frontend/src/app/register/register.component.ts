import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  
  returnUrl: string="";
  signedData:any ;
  errors:boolean=false;
  errorStr:String="Signup error";
  signUpForm = new FormGroup({});

  constructor(private fb:FormBuilder,
    private userService: UserService,
    private router:Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.signUpForm = this.fb.group({
      email : ['',Validators.required],
      password:['',Validators.required],
      name:['',Validators.required],
      gender:['',Validators.required],
      mobile:['',Validators.required]
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  signUp(value:any){
    localStorage.removeItem("loginDetails");
   this.userService.addUser(value). subscribe(data=> {
    this.signedData = data;

      //this.login(this.signedData);
   
       }, error=>console.log(error))

  }
  
}


  