import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Flight } from '../model/flight';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  private baseUrl = 'http://localhost:8081/flight'; 

  constructor(
    public  http : HttpClient
    ) { }

 

  updateFlights(flight:Flight) :  Observable<Flight>{
    return this.http.put<Flight>(this.baseUrl,flight);
  }

  

  public addFlights(flight:Flight): Observable<Flight>{
    
    return this.http.post<Flight>(this.baseUrl,flight);
  }

  getAllFlightsData(): Observable<Flight[]>{
    return this.http.get<Flight[]>(this.baseUrl);
  }

  getFlightById(flightId: number): Observable<Flight>{
    return this.http.get<Flight>(this.baseUrl + '/getScheduleById/' + flightId);
  }

  deleteFlight(id:number){
    return this.http.delete<number>(this.baseUrl+"/"+id);
  }
}
