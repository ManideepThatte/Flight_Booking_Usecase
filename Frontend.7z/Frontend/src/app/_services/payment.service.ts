import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  private baseUrl = 'http://localhost:8083/book'; 
  constructor(
    public  http : HttpClient
  ) { }

  public addBookingDetails(bookingDetails:any): Observable<any>{

    console.log(bookingDetails);
    return this.http.post<any>(this.baseUrl,bookingDetails);
  }

  getBookingsByEmail(email:string): Observable<any>{
    return this.http.get<any>(this.baseUrl+"/" + email);
  }

  checkedIn(pnr:string): Observable<any>{
    console.log(pnr);
    return this.http.get<any>(this.baseUrl+"/checkin/" + pnr);
  }

  cancelTicket(id:number): Observable<any>{
    return this.http.get<any>(this.baseUrl+"/cancel/" + id);
  }

}
