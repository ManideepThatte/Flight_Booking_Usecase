import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8082/signup'; 
  private authUrl = "http://localhost:8081/authenticate";
  
  constructor(
   public httpClient: HttpClient,
   public rout: Router
  ) { }

  public addUser(user:User): Observable<User>{
    console.log(user);
    return this.httpClient.post<User>(this.baseUrl,user);
  }

  isLoggedIn(){
    return !!localStorage.getItem('loginDetails');
  }


  checkLoginDetails(){
    // return !!localStorage.getItem('loginDetails');
    var checklogin = false;
    if (localStorage.getItem('loginDetails')) {
        
      let details:any = localStorage.getItem('loginDetails')||{};
      let dateex:Date = JSON.parse(details).expiryTime;
      var rxpdate = new Date(dateex);
      console.log("expire:" +dateex);
      let roles = JSON.parse(details).roles;
      console.log(roles);
        if (rxpdate.getTime() > new Date().getTime()){
          checklogin= true;
          }
    }

    return checklogin;
   
  }

  checkAdminDetails(){
    // return !!localStorage.getItem('loginDetails');
    var checklogin = false;
    if (localStorage.getItem('loginDetails')) {
        
      let details:any = localStorage.getItem('loginDetails')||{};
      console.log("login called");
      let roles = JSON.parse(details).roles;
      if (roles.includes("ROLE_ADMIN")){

          checklogin= true;
          }
    }

    return checklogin;
   
  }

  public login(user:User): Observable<User>{
    console.log('logout called');
    return this.httpClient.post<User>(this.authUrl,user);

  }


  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('loginDetails');
    this.rout.navigateByUrl('/login');
}
}
