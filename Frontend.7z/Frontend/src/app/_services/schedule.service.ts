import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { Schedule } from '../model/schedule';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {

  url = 'http://localhost:8081/schedule';  
   
  constructor(private http: HttpClient) { }  
   
  getAllSchedule(): Observable<Schedule[]> {  
    return this.http.get<Schedule[]>(this.url);  
  }  
   
  getScheduleById(scheduleId: string): Observable<Schedule> {  
    return this.http.get<Schedule>(this.url + '/getScheduleById/' + scheduleId);  
  }  
   
  addSchedule(schedule: Schedule): Observable<Schedule> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<Schedule>(this.url, schedule, httpOptions);  
  }  
   
  updateSchedule(schedule: Schedule): Observable<Schedule> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   
    return this.http.put<Schedule>(this.url + '/updateSchedule/',  
    schedule, httpOptions);  
  }  
   
  deleteSchedule(id:number){  
    console.log(this.url+"/"+id);
    return this.http.delete<number>(this.url+"/"+id);
  }   
   
  deleteData(schedule: Schedule[]): Observable<string> {  
    const httpOptions = {  
      headers: new HttpHeaders({  
        'Content-Type': 'application/json'  
      })  
    };  
    return this.http.post<string>(this.url + '/deleteRecord/', schedule, httpOptions);  
  }
  
  public getScheduledFlights(schedule:Schedule): Observable<Schedule>{

    return this.http.post<Schedule>(this.url+"/flights",schedule);
  }

}
