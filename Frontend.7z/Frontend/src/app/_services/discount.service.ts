import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Discount } from '../model/discount';

@Injectable({
  providedIn: 'root'
})
export class DiscountService {

  constructor(
    public  http : HttpClient
  ) { }

  private baseUrl = 'http://localhost:8081/promo';
  private securl = 'http://localhost:8081/api/v1/promo' ;

  public addPromo(promo:Discount): Observable<Discount>{
   

    return this.http.post<Discount>(this.baseUrl,promo);
  }

  getAllFlightsData(): Observable<Discount>{
    return this.http.get<Discount>(this.baseUrl);
  }

  deletePromo(id:number){
    return this.http.delete<number>(this.baseUrl+"/"+id);
  }


  public updatepromo(promo:Discount): Observable<Discount>{

    
    let details:any = localStorage.getItem('loginDetails')||{};
       
   let token:string= JSON.parse(details).token;
   let tokenStr:string = 'Bearer ' + token;
   
    console.log(tokenStr);
        var header = {
          headers: new HttpHeaders()
            .set('Authorization',  tokenStr)
        }

    return this.http.put<Discount>(this.securl,promo,header);
  }


}
