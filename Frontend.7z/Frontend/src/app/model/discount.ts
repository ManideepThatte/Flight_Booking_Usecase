export class Discount{

        flightId: number;
        code: String;
        discount: number;
        expiryDate: Date;

}
