export class User{
  constructor(
    private name:string,
    private gender:string,
    private email:string,
    private mobile:string,
    private password:string,
    private expiryTime:Date,
    private roles:string[],
    private token:string

    ){}
}
