export class Flight{
    constructor(
        name: String,
        email: String,
        contact: String
        ){}

}