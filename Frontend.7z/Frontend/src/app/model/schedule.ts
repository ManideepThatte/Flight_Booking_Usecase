import { Time } from "@angular/common";

export class Schedule {
    constructor(
        flightId:number ,
        sourceCity:String,
        sourceDate:Date,
        sourceTime:Time,
        destinationCity:String,
        destinationDate:Date,
        destinationTime:Time,
        cost: number
        ){}
    }
