import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../_services/payment.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  paymnetDetails: any;
  bookingDetails: any = {};
  paymentForm = new FormGroup({});
  totalCost:number=0;
  constructor(
    private router: Router,
    private activatedRouter: ActivatedRoute,
    private fb:FormBuilder,
    private paymentService:PaymentService
  ) {

  }

  ngOnInit(): void {

    this.paymnetDetails = history.state;
    localStorage.getItem('paymnetDetails');
    this.paymnetDetails = JSON.parse(localStorage.getItem("paymnetDetails") || '{}');
    this.totalCost=(this.paymnetDetails.cost* this.paymnetDetails.numberOfPassengers);
    this.paymentForm = this.fb.group({
      name : ['',Validators.required],
      number:['',Validators.required],
      cvv:['',Validators.required],
      expiry:['',Validators.required],

  });
  }

  payment (value:any){

    value.amount=this.totalCost;
    this.bookingDetails.scheduleDto = this.paymnetDetails;
    this.bookingDetails.paymentDto = value;
    this.bookingDetails.userDto = JSON.parse(localStorage.getItem('loginDetails')  || '{}');

    this.paymentService.addBookingDetails(this.bookingDetails) .subscribe(data=> {
      console.log(data);
      alert("payment Success redirecting to Booking History");
         }, error=>console.log(error));

         this.router.navigate(['user/history']);

  }


}
