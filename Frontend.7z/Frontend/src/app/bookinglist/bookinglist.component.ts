import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightService } from '../_services/flight.service';
import { ScheduleService } from '../_services/schedule.service';

@Component({
  selector: 'app-bookinglist',
  templateUrl: './bookinglist.component.html',
  styleUrls: ['./bookinglist.component.scss']
})
export class BookinglistComponent implements OnInit {

  bookingFrom = new FormGroup({});
  City:any = ['Hyderabad',"Mumbai","Bangalore","Chennai"];
  public flightScheduleData:any=[];

  isSubmitted = false;


  constructor(private fb:FormBuilder,
    private flightService : FlightService,
    private schduleService:ScheduleService
    ) { }

  ngOnInit(): void {

    this.bookingFrom = this.fb.group({
      sourceCity : ['',Validators.required],
      destinationCity:['',Validators.required],
      sourceDate:['',Validators.required],
      numberOfPassengers:['',Validators.required]
   
    })
  }

 

  bookTickets(value:any):boolean {
    

    if (!this.bookingFrom.valid) {
      return false;
    } else {
      this.isSubmitted = true;
      this.schduleService.getScheduledFlights(value) .subscribe(data=> {
        this.flightScheduleData = data;
        console.log(data);
           }, error=>console.log(error));
      return true;
    }
    
  }

  get f():any{
    return this.bookingFrom.controls;
  }

}
