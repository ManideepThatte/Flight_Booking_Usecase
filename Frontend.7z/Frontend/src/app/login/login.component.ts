import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginFrom = new FormGroup({});
  signUpForm = new FormGroup({});
  signedData:any ;
  returnUrl: string="";
 

  errors:boolean=false;
  errorStr:String="My error";

  @Input()  requesturl:string="";

  url:any="";

 
  constructor(private fb:FormBuilder,
    private userService: UserService,
    private router:Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.loginFrom = this.fb.group({
      email : ['',Validators.required],
      password:['',Validators.required]
    

    });

    this.signUpForm = this.fb.group({
      email : ['',Validators.required],
      password:['',Validators.required],
      name:['',Validators.required],
      gender:['',Validators.required],
      mobile:['',Validators.required]
    });

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

  }

  login (value:any){

    localStorage.removeItem("loginDetails");
    console.log(value);
    this.userService.login(value).subscribe(data=>{
      console.log("login data: "+data);
      localStorage.setItem('loginDetails',JSON.stringify(data));
      console.log("not name here")
      this.router.navigate([this.returnUrl]);


    },(error)=>{
      console.log(error.errorMessage);
      alert("unable to login");
      this.errorStr = error.errorMessage;
      this.errors=true;
      console.log(this.errorStr);
    });

  }

  signUp(value:any){
    localStorage.removeItem("loginDetails");
   this.userService.addUser(value). subscribe(data=> {
    this.signedData = data;

      this.login(this.signedData);
   
       }, error=>console.log(error))

  }
  
  
}
