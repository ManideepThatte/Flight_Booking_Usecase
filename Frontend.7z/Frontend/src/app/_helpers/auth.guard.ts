import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { UserService } from "../_services/user.service";

@Injectable({
    providedIn: 'root'
  })
  export class AuthGuard implements CanActivate {
    
    constructor(public userService: UserService,
      public router:Router) {}
  
     
  
      canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (localStorage.getItem('loginDetails')) {
          
          let details:any = localStorage.getItem('loginDetails')||{};
          console.log(details);
          let dateex:Date =JSON.parse(details).expiryTime;
          let rxpdate = new Date(dateex);
            if ( (rxpdate.getTime() > new Date().getTime())){
            return true;
            }
        }
  
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
        return false;
    }
  
    
  }
  