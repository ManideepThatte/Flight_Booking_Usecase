import { Component, OnInit } from '@angular/core';
import jsPDF from 'jspdf';
import 'jspdf-autotable' ;
import { data } from '../data';
import { PaymentService } from '../_services/payment.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {

  tabData = data;
  bookingList:any=[];
   userDetails:any ={};

  constructor( private paymentService: PaymentService) { }

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('loginDetails') || '{}');
    this.getAllFightsList();
  }
  getAllFightsList() {
    this.paymentService.getBookingsByEmail(this.userDetails.email)
    .subscribe(
      (response:any) => {                           //next() callback
        console.log(response);
        this.bookingList = response.bookings; 
        
      },
      (error) => {                              //error() callback
        console.error('Request failed with error')
       
      },
      () => {                                   //complete() callback
        console.error('Request completed')      //This is actually not needed 
      
      })


  }

  openPdf(tdata:any){

    var head=[['Content','value']];

    var tabledata = [
      ['Flight Name',tdata.flightName],
      
                        ['Source',tdata.sourceCity],
                        ['Source Date',tdata.sourceDate],
                        ['Source Time',tdata.sourceTime],
                        ['Destination',tdata.destinationCity],
                        ['Destination Date',tdata.destinationDate],
                        ['Destination Tine',tdata.destinationTime],
                        ['No of Passengers',tdata.numberOfPassengers],
                        ['Amount',tdata.payment.amount],
                        ['PNR',tdata.pnr],
                        ['Status',tdata.status]
    ];

    var doc = new jsPDF();

    doc.setFontSize(18);
    doc.text(tdata.email, 11, 8);
    doc.setFontSize(12);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: tabledata,
      theme: 'plain',
      tableLineColor: [0, 0, 0],
      bodyStyles: {
        margin: 40,
        fontSize: 10,
        lineWidth: 0.2,
        lineColor: [0, 0, 0]
    }
    })


    doc.save('booking.pdf');
  }

  cancelTicket(cancelData:any){
    this.paymentService.cancelTicket(cancelData.id).subscribe(data=> {
      console.log(data);
         }, error=>console.log(error));


         this.ngOnInit()

  }

}
