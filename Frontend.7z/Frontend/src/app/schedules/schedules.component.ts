import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { flightTimeData } from '../data';
import { Flight } from '../model/flight';
import { FlightService } from '../_services/flight.service';
import { ScheduleService } from '../_services/schedule.service';

@Component({
  selector: 'app-schedules',
  templateUrl: './schedules.component.html',
  styleUrls: ['./schedules.component.scss']
})
export class SchedulesComponent implements OnInit {

  @ViewChild('closebutton') closebutton:any;

  manageTimings = flightTimeData;
  public closeResult:any="";
  addScheduleFrom = new FormGroup({});
  updateScheduleForm=new FormGroup({});
  public flightListData:any=[];
  public flightScheduleData:any=[];
  public deleteId:number = 0;
  public updatedId:number=0;

  constructor(private modalService: NgbModal,
    private fb: FormBuilder,
    private flightService : FlightService,
    private flightSchduleService:ScheduleService) { }

  ngOnInit(): void {

    this.addScheduleFrom = this.fb.group({
      flightId: ['', Validators.required],
      sourceCity: ['', Validators.required],
      sourceDate: ['', Validators.required],
      sourceTime: ['', Validators.required],
      destinationCity: ['', Validators.required],
      destinationDate: ['', Validators.required],
      destinationTime: ['', Validators.required],
      cost: ['', Validators.required]

    });

    this.updateScheduleForm = this.fb.group({
      flightId: ['', Validators.required],
      sourceCity: ['', Validators.required],
      sourceDate: ['', Validators.required],
      sourceTime: ['', Validators.required],
      destinationCity: ['', Validators.required],
      destinationDate: ['', Validators.required],
      destinationTime: ['', Validators.required],
      flightName: ['', Validators.required],
      cost: ['', Validators.required]

    });


    this.getAllFightsList();
    this.getAllSchedules();
  }

  addSchedule(value:any){
    console.log(value);
    this.flightSchduleService.addSchedule(value) .subscribe(data=>{
      alert("success");
       console.log(data);
      this.getAllSchedules();
    }, (error) => {                              
     alert(error.errorMessage);
      
    })
  }

  openEdit(content: any,data:any) {
    console.log(data);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.updatedId = data.id;
    
    
    this.updateScheduleForm.patchValue({
      flightId: data.flightId,
      sourceCity: data.sourceCity,
      sourceDate: data.sourceDate,
      sourceTime: data.sourceTime,
      destinationCity: data.destinationCity,
      destinationDate: data.destinationDate,
      destinationTime: data.destinationTime,
      cost:data.cost,
      flightName:data.flight.name
     });

  
  }


  private formatDate(date:Date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
  }

  getAllFightsList() {
    this.flightService.getAllFlightsData()
    .subscribe(
      (response:Flight) => {                          
        console.log('response received')
        this.flightListData = response; 
        
      },
      (error) => {                              
        console.error('Request failed with error')
        

      });

  }

  openDelete(content: any,data:any) {
    console.log(data);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.deleteId = data.id;
    
  }


  deleteSchedule(){

    this.flightSchduleService.deleteSchedule(this.deleteId)
    .subscribe(data=> {console.log(data);
      this.modalService.dismissAll();
    },
    (error)=>{
      alert(error.error)
      console.log(error)
    });
  
  this.getAllSchedules();
  }

  getAllSchedules() {
    this.flightSchduleService.getAllSchedule()
    .subscribe(
      (response:Flight) => {                           //next() callback
        this.flightScheduleData = response; 
        
      },
      (error) => {                              //error() callback
        console.error('Request failed with error')
       
      });


  }



  open(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }

  updateSchedule(value:any){
    console.log(value);
    value.id=this.updatedId;
    this.flightSchduleService.updateSchedule(value) .subscribe(data=>{
      alert("success");
       console.log(data);
      this.getAllSchedules();
    }, (error) => {                              
     alert(error.errorMessage);
      
    })
  }
  
  

}
