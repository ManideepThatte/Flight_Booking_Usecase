package com.cts.bookingservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.cts.bookingservice.exception.BookingsNotFoundException;
import com.cts.bookingservice.mapper.BookingMapper;
import com.cts.bookingservice.model.Booking;
import com.cts.bookingservice.repository.BookingRepository;
import com.cts.bookingservice.service.BookingService;
import com.cts.bookingservice.vo.BookingDetailsVO;

@Service
public class BookingServiceImpl implements BookingService{

	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
    private KafkaTemplate<String, Booking> kafkaTemplate;
	
	private static final String TOPIC = "messageservice";
	
	
	@Override
	public void addBookingDetails(BookingDetailsVO bookingDetailsDto) {
		
		Booking booking = BookingMapper.getBookingDetails(bookingDetailsDto);
		Booking savedBooking = bookingRepository.save(booking);
        kafkaTemplate.send(TOPIC, savedBooking);

	}
	
	@Override
	public  BookingDetailsVO getBookingDetailsByEmail(String email) {
		
		BookingDetailsVO dto = new BookingDetailsVO();
		List<Booking> bookings = bookingRepository.getBookingsByEmail(email);
		dto.setBookings(bookings);
		return dto;
		
	}

	@Override
	public void getcheckIn(String pnr) {
		
		Booking booking = bookingRepository.getBookingByPnr(pnr);
		if (booking==null) {
			throw new BookingsNotFoundException("PNR Not Found");
		}
		
		booking.setStatus("checked-in");
		bookingRepository.save(booking);
		
	}

	@Override
	public void cancelTicket(Long id) {
		Booking booking = bookingRepository.findOneByIdAndIsActive(id, true);
		if (booking==null) {
			throw new BookingsNotFoundException("Unable to Cancel Ticket");
		}
		
		booking.setStatus("cancelled");
		bookingRepository.save(booking);
	}
	
	
	

}
