package com.cts.bookingservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.bookingservice.model.Booking;

@Repository
public interface BookingRepository extends AbstractRepository<Booking, Long>{

	@Query( " FROM Booking as booking "
			+ " LEFT JOIN FETCH booking.payment as payment "
			+ " WHERE booking.isActive=true and "
			+ " booking.email=:email")
	public List<Booking> getBookingsByEmail(String email);

	
	@Query(" FROM Booking as booking "
			+ " WHERE booking.pnr=:pnr "
			+ " and isActive=true")
	public Booking getBookingByPnr(String pnr);
}
