package com.cts.bookingservice.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name="booking")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class Booking extends BaseModel{
	
	private Long scheduleId;
	private String email;
	private String flightName;
	
	@Temporal(TemporalType.DATE)
	private Date sourceDate;
	@Temporal(TemporalType.DATE)
	private Date destinationDate;
	private Long cost;
	private String sourceTime;
	private String destinationTime;
	private String sourceCity;
	private String destinationCity;
	private Long flightId;
	private Long numberOfPassengers;
	private String pnr;
	private String status;
	
	@OneToOne(targetEntity = Payment.class,fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="paymentId")
	private Payment payment;

	
	

}
