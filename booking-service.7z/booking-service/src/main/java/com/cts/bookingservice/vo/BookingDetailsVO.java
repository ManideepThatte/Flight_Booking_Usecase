package com.cts.bookingservice.vo;

import java.util.List;

import com.cts.bookingservice.model.Booking;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BookingDetailsVO extends BaseVO{

	private ScheduleVO scheduleDto;
	private PaymentVO paymentDto;
	private UserVO userDto;
	private List<Booking> bookings;
}
