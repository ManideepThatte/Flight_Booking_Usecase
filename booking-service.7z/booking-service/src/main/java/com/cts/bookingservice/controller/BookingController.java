package com.cts.bookingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bookingservice.exception.BookingsNotFoundException;
import com.cts.bookingservice.service.BookingService;
import com.cts.bookingservice.vo.BaseVO;
import com.cts.bookingservice.vo.BookingDetailsVO;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "*")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@PostMapping
	public ResponseEntity<BookingDetailsVO> bookTicket(@RequestBody BookingDetailsVO bookingVO) {
		BookingDetailsVO response = new BookingDetailsVO();
		try {
			bookingService.addBookingDetails(bookingVO);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@GetMapping("/{email}")
	public ResponseEntity<BookingDetailsVO> bookTicket(@PathVariable("email") String email) {
		BookingDetailsVO response = new BookingDetailsVO();

		try {
			response = bookingService.getBookingDetailsByEmail(email);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (BookingsNotFoundException e) {

			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

		} catch (Exception e) {

			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@GetMapping("/checkin/{pnr}")
	public ResponseEntity<BaseVO> checkIn(@PathVariable("pnr") String pnr) {
		BookingDetailsVO response = new BookingDetailsVO();

		try {
			bookingService.getcheckIn(pnr);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {

			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		}

	}
	
	@GetMapping("/cancel/{id}")
	public ResponseEntity<BaseVO> cancelTicket(@PathVariable("id") Long id) {
		BookingDetailsVO response = new BookingDetailsVO();

		try {
			bookingService.cancelTicket(id);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {

			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		}

	}

}
