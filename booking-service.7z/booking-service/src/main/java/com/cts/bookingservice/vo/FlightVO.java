package com.cts.bookingservice.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)

public class FlightVO extends BaseVO{

	private String name;
    
	private String url;
    
	private String email;
    
	private String contact;
    
    
}