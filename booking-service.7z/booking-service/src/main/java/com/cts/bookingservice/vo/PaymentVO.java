package com.cts.bookingservice.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PaymentVO extends BaseVO{
	
	private String name;
	private String number;
	private String expiry;
	private Long cvv;
	private Long amount;
	private String email;

}
