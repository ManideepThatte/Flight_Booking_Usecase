package com.cts.bookingservice.exception;

public class BookingsNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BookingsNotFoundException(String mesage) {
		super(mesage);
	}

}
