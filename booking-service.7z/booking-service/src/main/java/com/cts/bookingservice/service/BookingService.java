package com.cts.bookingservice.service;

import com.cts.bookingservice.vo.BookingDetailsVO;

public interface BookingService {
	public void addBookingDetails (BookingDetailsVO bookingDetailsDto);

	BookingDetailsVO getBookingDetailsByEmail(String email);

	public void getcheckIn(String pnr);

	public void cancelTicket(Long id);

}
