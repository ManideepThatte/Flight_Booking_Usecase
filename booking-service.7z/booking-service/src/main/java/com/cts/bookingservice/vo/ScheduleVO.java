package com.cts.bookingservice.vo;

import java.util.Date;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode
public class ScheduleVO {

	private Long id;
	private FlightVO flight;
	
	@Temporal(TemporalType.DATE)
	private Date sourceDate;
	
	@Temporal(TemporalType.DATE)
	private Date destinationDate;
	
	private Long cost;
	private String sourceTime;
	private String destinationTime;
	private String sourceCity;
	private String destinationCity;
	private Long flightId;
	private Long numberOfPassengers;
	private List<ScheduleVO> schedulesList;
}
