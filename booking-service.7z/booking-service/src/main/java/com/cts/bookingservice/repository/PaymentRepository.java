package com.cts.bookingservice.repository;

import org.springframework.stereotype.Repository;

import com.cts.bookingservice.model.Payment;

@Repository
public interface PaymentRepository extends AbstractRepository<Payment, Long> {

}
