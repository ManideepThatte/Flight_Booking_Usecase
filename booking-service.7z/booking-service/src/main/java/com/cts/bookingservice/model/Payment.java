package com.cts.bookingservice.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name="payment")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class Payment extends BaseModel{

	private String name;
	private String number;
	private String expiry;
	private Long cvv;
	private Long amount;
	private String email;
	
	
	
	
}
