package com.cts.bookingservice.mapper;

import java.util.Date;

import com.cts.bookingservice.model.Booking;
import com.cts.bookingservice.model.Payment;
import com.cts.bookingservice.vo.BookingDetailsVO;
import com.cts.bookingservice.vo.PaymentVO;
import com.cts.bookingservice.vo.ScheduleVO;
import com.cts.bookingservice.vo.UserVO;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BookingMapper {

	public static Booking getBookingDetails(BookingDetailsVO dto) {
		
		Booking booking = new Booking();
		ScheduleVO scDto = dto.getScheduleDto();
		UserVO userDto = dto.getUserDto();
		PaymentVO paymentDto = dto.getPaymentDto();
		
		booking.setScheduleId(dto.getScheduleDto().getId());
		booking.setEmail(userDto.getEmail());
		booking.setDestinationCity(scDto.getDestinationCity());
		booking.setDestinationDate(scDto.getDestinationDate());
		booking.setDestinationTime(scDto.getDestinationTime());
		booking.setSourceCity(scDto.getSourceCity());
		booking.setSourceDate(scDto.getSourceDate());
		booking.setSourceTime(scDto.getSourceTime());
		booking.setNumberOfPassengers(scDto.getNumberOfPassengers());
		booking.setFlightId(scDto.getFlight().getId());
		booking.setFlightName(scDto.getFlight().getName());
		booking.setCost(scDto.getCost());
		
		Payment payment = new Payment();
		payment.setAmount(paymentDto.getAmount());
		payment.setCvv(paymentDto.getCvv());
		payment.setName(paymentDto.getName());
		payment.setEmail(userDto.getEmail());
		payment.setExpiry(paymentDto.getExpiry());
		payment.setNumber(paymentDto.getNumber());
		booking.setPayment(payment);
		booking.setStatus("booked");

	    long msec = new Date().getTime();
		String pnr = userDto.getEmail().substring(0,4)+msec;
		booking.setPnr(pnr);
		return booking;
		
	}
}
