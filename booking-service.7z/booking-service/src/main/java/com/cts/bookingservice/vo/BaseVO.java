package com.cts.bookingservice.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseVO {

	private Long id;
	private Boolean isActive;
	private String createdDate;
	private String modifiedDate;
	private String userUuid; 
	private String errorMessage;
}
