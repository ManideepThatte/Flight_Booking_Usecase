package com.cts.userservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.userservice.exception.UserAlreadyExistsException;
import com.cts.userservice.model.Role;
import com.cts.userservice.model.User;
import com.cts.userservice.repository.RoleRepository;
import com.cts.userservice.repository.UserRepository;
import com.cts.userservice.repository.UserRoleRepository;
import com.cts.userservice.serivce.UserService;
import com.cts.userservice.service.serviceImpl.UserServiceImpl;
import com.cts.userservice.vo.UserDto;

@SpringBootTest
public class UserserviceApplicationTests {

	@Test
	public void contextLoads() {
		
	}
	
	@InjectMocks
	private UserService userService= new UserServiceImpl();
	
	@Mock
	private UserRepository userRepository;
	
	@Mock
	private RoleRepository roleRepository;
	
	@Mock
	private UserRoleRepository userRoleRepository;
	
	@Test
	public void addUser() throws Exception{
		
		UserDto user = new UserDto();
		user.setName("name");
		user.setEmail("email");
		user.setPassword("password");
		user.setGender("male");
		user.setMobile("mobile");
		
		User newUser = new User();
		newUser.setName("name");
		newUser.setEmail("email");
		newUser.setPassword("password");
		newUser.setGender("male");
		newUser.setMobile("mobile");
		
		Role role = new Role();
		role.setName("user");
		role.setCode("user");
		Mockito.when(userRepository.getUserObjectByEmail(user.getEmail())).thenReturn(null);
		Mockito.when(roleRepository.getRoleByName("user")).thenReturn(role);
		
		Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(newUser);


		UserDto expected = userService.addUser(user);
		assertEquals(user.getEmail(),expected.getEmail());
		
		
	}
	
	@Test
	public void addUserThrowsExceptionn() throws Exception{
		
		UserDto user = new UserDto();
		user.setName("name");
		user.setEmail("email");
		user.setPassword("password");
		user.setGender("male");
		user.setMobile("mobile");
		
		User newUser = new User();
		newUser.setName("name");
		newUser.setEmail("email");
		newUser.setPassword("password");
		newUser.setGender("male");
		newUser.setMobile("mobile");
		
		Role role = new Role();
		role.setName("user");
		role.setCode("user");
		Mockito.when(userRepository.getUserObjectByEmail(user.getEmail())).thenReturn(newUser);

		UserAlreadyExistsException exception = assertThrows(UserAlreadyExistsException.class, () -> {
			userService.addUser(user);
	    });
		
		
		assertEquals("User already Exists ..... Please Login!...", exception.getMessage());
		 
		
		
	}
	
	

}
