package com.cts.userservice.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.userservice.exception.UserAlreadyExistsException;
import com.cts.userservice.mapper.UserDtoMapper;
import com.cts.userservice.model.Role;
import com.cts.userservice.model.User;
import com.cts.userservice.model.UserRoleMapper;
import com.cts.userservice.repository.RoleRepository;
import com.cts.userservice.repository.UserRepository;
import com.cts.userservice.repository.UserRoleRepository;
import com.cts.userservice.serivce.UserService;
import com.cts.userservice.vo.UserDto;

@Service
@Transactional(rollbackFor = Exception.class)
public class UserServiceImpl implements UserService{
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private UserRoleRepository userRoleRepository;
	
	@Override
	public User getUserRolesByEmail(String email){
		
		return userRepository.getUserObjectByEmail(email);

	}


	@Override
	public UserDto addUser(UserDto userDto) throws UserAlreadyExistsException{
		
		User user = userRepository.getUserObjectByEmail(userDto.getEmail().toLowerCase());
		if (user!=null) {
			throw new  UserAlreadyExistsException("User already Exists ..... Please Login!...");
		}
		User newUser = new User();
		newUser.setEmail(userDto.getEmail().toLowerCase());
		newUser.setPassword(userDto.getPassword());
		newUser.setGender(userDto.getGender());
		newUser.setMobile(userDto.getMobile());
		Role role = roleRepository.getRoleByName("user");
		UserRoleMapper mapper = new UserRoleMapper();
		mapper.setRole(role);
		
		User savedUser =  userRepository.save(newUser);
		mapper.setUser(savedUser);
		userRoleRepository.save(mapper);
		return UserDtoMapper.fromUser(savedUser);
	}
	
	@Override
	public List<UserRoleMapper> getAllUsersRoleMappers() {
		try {
		return userRoleRepository.getAllUserRoleMappers();
		} catch (Exception e) {
			return new ArrayList<>();
		}
	}
	

	@Override
	public List<UserRoleMapper> getAllUsers(String email) {
		return  userRoleRepository.getAllUserRoleMappersByEmail(email.toLowerCase());
	}
	
	
	
}
