package com.cts.userservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.userservice.model.UserRoleMapper;
import com.cts.userservice.serivce.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")

public class UserController {

	
	@Autowired
	private UserService userService;
	
	@GetMapping
	public ResponseEntity<List<UserRoleMapper>> getAllUserRoles(){
		try {
		return new ResponseEntity<>(userService.getAllUsersRoleMappers(),HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity<>(new ArrayList<>(),HttpStatus.BAD_REQUEST);

		}
	}
	
	
	@GetMapping("/{email}")
	public ResponseEntity<List<UserRoleMapper>> getAllUserRoleMappersByUser(@PathVariable("email")String email){
		try {
		return new ResponseEntity<>(userService.getAllUsers(email),HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity<>(new ArrayList<>(),HttpStatus.NOT_FOUND);

		}
	}
}
