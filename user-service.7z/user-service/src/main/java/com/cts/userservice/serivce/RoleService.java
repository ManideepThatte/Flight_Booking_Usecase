package com.cts.userservice.serivce;

import com.cts.userservice.model.Role;

public interface RoleService {

	public Role getRoleByRoleId (Long id);
}
