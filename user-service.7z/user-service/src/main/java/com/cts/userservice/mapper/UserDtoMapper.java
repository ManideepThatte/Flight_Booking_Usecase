package com.cts.userservice.mapper;

import com.cts.userservice.model.User;
import com.cts.userservice.vo.UserDto;

import lombok.experimental.UtilityClass;

@UtilityClass
public class UserDtoMapper {
	
	public static UserDto fromUser(User user) {
		
		UserDto userDto = new UserDto();
		userDto.setName(user.getName());
		userDto.setGender(user.getGender());
		userDto.setMobile(user.getMobile());
		userDto.setEmail(user.getEmail());
		userDto.setPassword(user.getPassword());
		return userDto;
		
		
	}
	
public static UserDto fromUserAllUserRoles(User user) {
		
		UserDto userDto = new UserDto();
		userDto.setName(user.getName());
		userDto.setGender(user.getGender());
		userDto.setMobile(user.getMobile());
		userDto.setEmail(user.getEmail());
		userDto.setPassword(user.getPassword());
		return userDto;
		
		
	}

}
