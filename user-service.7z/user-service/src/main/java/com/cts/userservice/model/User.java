package com.cts.userservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user")

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class User extends BaseModel {

	private String name;
	private String gender;
	private String mobile;
	@Column(nullable = false, unique = true)
	private String email;
	@Column(nullable = false)
	private String password;

	



}
