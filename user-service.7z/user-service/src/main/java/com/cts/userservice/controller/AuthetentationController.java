package com.cts.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.userservice.exception.UserAlreadyExistsException;
import com.cts.userservice.serivce.UserService;
import com.cts.userservice.vo.UserDto;

@RestController
@RequestMapping("/signup")
@CrossOrigin(origins = "*")
public class AuthetentationController {

	@Autowired
	private UserService userService;

	@PostMapping
	public ResponseEntity<UserDto> signUp(@RequestBody UserDto userDto) {

		UserDto response = new UserDto();
		try {

			response = userService.addUser(userDto);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (UserAlreadyExistsException e) {
			e.printStackTrace();
			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		} catch (Exception e) {
			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
}
