package com.cts.userservice.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.userservice.model.Role;

@Repository
public interface RoleRepository extends AbstractRepository<Role, Long>{

	@Query (" FROM Role as role "
			+ " Where role.name=:name ")
	public Role getRoleByName(String name);
}
