package com.cts.userservice.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "userrolemapper")

@EqualsAndHashCode(callSuper = true)
@Data
public class UserRoleMapper extends BaseModel {

	
	@ManyToOne(targetEntity = User.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "userId")
	private User user;
	
	@ManyToOne(targetEntity = Role.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "roleId")
	private Role role;
	
	public UserRoleMapper() {}
	
	
	public UserRoleMapper(User user, Role role) {
		super();
		this.user = user;
		this.role = role;
	}
}
