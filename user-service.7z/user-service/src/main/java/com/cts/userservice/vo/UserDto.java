package com.cts.userservice.vo;

import javax.persistence.Column;

import com.cts.userservice.model.Role;
import com.cts.userservice.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

	private String name;
	private String gender;
	private String mobile;
	@Column(nullable = false, unique = true)
	private String email;
	@Column(nullable = false)
	private String password;
	private String errorMessage;
	private User user;
	private Role role;
	
}
