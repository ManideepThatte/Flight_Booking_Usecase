package com.cts.userservice.service.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.userservice.model.Role;
import com.cts.userservice.repository.RoleRepository;
import com.cts.userservice.serivce.RoleService;

@Service
public class RoleServiceImpl implements RoleService{

	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public Role getRoleByRoleId(Long id) {
		
		return roleRepository.findOneByIdAndIsActive(id, Boolean.TRUE);
	}

	
}
