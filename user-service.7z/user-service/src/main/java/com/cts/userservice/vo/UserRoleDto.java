package com.cts.userservice.vo;

import java.util.List;
import java.util.Set;

import com.cts.userservice.model.UserRoleMapper;

import lombok.Data;

@Data
public class UserRoleDto {

	public List<UserRoleMapper> userroles;
}
