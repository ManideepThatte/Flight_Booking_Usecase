package com.cts.userservice.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.userservice.model.User;

@Repository
public interface UserRepository extends AbstractRepository<User, Long>{

	
	@Query(" FROM User as user "
			+ " WHERE user.email=:email"
			+ " and user.isActive=true ")
	public User getUserObjectByEmail(String email);

	
	

}
