package com.cts.userservice.serivce;

import java.util.List;
import com.cts.userservice.model.User;
import com.cts.userservice.model.UserRoleMapper;
import com.cts.userservice.vo.UserDto;

public interface UserService {

	UserDto addUser(UserDto userDto);

	User getUserRolesByEmail(String email);

	List<UserRoleMapper> getAllUsersRoleMappers();


	List<UserRoleMapper> getAllUsers(String email);

}
