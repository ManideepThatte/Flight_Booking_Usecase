package com.cts.userservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.userservice.model.UserRoleMapper;

@Repository
public interface UserRoleRepository extends AbstractRepository<UserRoleMapper, Long>{
	
	
	@Query ( " FROM UserRoleMapper mapper "
			+ " LEFT JOIN FETCH mapper.user as user "
			+ " LEFT JOIN FETCH mapper.role as role ")
	
	public List<UserRoleMapper> getAllUserRoleMappers();
	
	@Query ( " FROM UserRoleMapper mapper "
			+ " LEFT JOIN FETCH mapper.user as user "
			+ " LEFT JOIN FETCH mapper.role as role "
			+ " WHERE lower(user.email)=:email "
			+ " AND user.isActive=true")
	
	public List<UserRoleMapper> getAllUserRoleMappersByEmail(String email);

}
